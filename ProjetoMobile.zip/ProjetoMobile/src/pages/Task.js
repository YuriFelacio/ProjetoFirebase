import { Text } from "react-native";

export default function Task(){
    <Text>Hi im Task!</Text>
}