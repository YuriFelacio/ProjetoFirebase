import { Text,View } from "react-native";

export default function Details(){
    <View>
        <Text>Hi im Details!</Text>
    </View>
}