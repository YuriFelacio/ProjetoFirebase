import { Text } from "react-native";

export default function NewTask(){
    <Text>Hi im NewTask!</Text>
}